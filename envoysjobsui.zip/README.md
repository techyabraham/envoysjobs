
  # Community Opportunity Platform UI

  This is a code bundle for Community Opportunity Platform UI. The original project is available at https://www.figma.com/design/RPzsduW374grPsSyoct2K6/Community-Opportunity-Platform-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  